package com.anangkur.kotlinexpertsubmission.feature.leagueDetail.detail

import androidx.lifecycle.ViewModel
import com.anangkur.kotlinexpertsubmission.data.model.LeagueDetail

class DetailLeagueViewModel : ViewModel(){
    var dataFromArgs: LeagueDetail? = null
}