package com.anangkur.kotlinexpertsubmission.feature.favourite

import com.anangkur.kotlinexpertsubmission.data.local.ankoSqlite.EventFavourite
import androidx.lifecycle.*
import com.anangkur.kotlinexpertsubmission.data.Repository
import com.anangkur.kotlinexpertsubmission.data.model.Result

class FavouriteViewModel(private val repository: Repository): ViewModel(){

}