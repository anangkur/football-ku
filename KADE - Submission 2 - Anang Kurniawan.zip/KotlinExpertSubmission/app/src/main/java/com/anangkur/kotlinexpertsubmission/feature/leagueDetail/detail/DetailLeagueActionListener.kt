package com.anangkur.kotlinexpertsubmission.feature.leagueDetail.detail

interface DetailLeagueActionListener {
    fun onClickWebsite(url: String)
}