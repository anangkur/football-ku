package com.anangkur.kotlinexpertsubmission.main

import com.anangkur.kotlinexpertsubmission.model.Teams

interface MainActionListener {
    fun onClickItem(data: Teams)
}